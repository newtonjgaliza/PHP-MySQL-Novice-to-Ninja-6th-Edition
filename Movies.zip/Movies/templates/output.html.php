<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Script output</title>
    </head>
    <body>
        <?=$output?>
    </body>
</html>