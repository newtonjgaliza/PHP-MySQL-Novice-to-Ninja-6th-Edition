<?php

try {
    $pdo = new PDO('mysql:host=localhost;dbname=movies;
    charset=utf8', 'ijdbuser2', 'mypassword');
    $pdo->setAttribute(PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION);
    $output = 'Database connection established.';
} catch (PDOException $e) {
    $output = 'Unable to connect to the database server: ' . $e;
}

include __DIR__ . '/templates/output.html.php';

?>