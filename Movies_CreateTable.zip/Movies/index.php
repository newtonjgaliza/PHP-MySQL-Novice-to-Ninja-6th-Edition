<?php

try {
    $pdo = new PDO('mysql:host=localhost;dbname=movies;
    charset=utf8', 'ijdbuser2', 'mypassword');
    $pdo->setAttribute(PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION);

    $sql = 'CREATE TABLE `Movies`(
    `id`INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `title`TEXT NOT NULL,
    `year`TEXT NOT NULL)';

    $pdo->exec($sql);
    $output = 'Movies table successfully created.';
} catch (PDOException $e) {
    $output = 'Database error:' . $e->getMessage() . ' in ' .
    $e->getFile . ':' . $e->getLine();
}

include __DIR__ . '/templates/output.html.php';

?>